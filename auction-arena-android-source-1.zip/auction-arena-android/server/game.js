const { ITEMS } = require('./items');
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function makeCode(existing) { let code; do { code = Array.from({length:6},()=>CODE_CHARS[Math.floor(Math.random()*CODE_CHARS.length)]).join(''); } while(existing.has(code)); return code; }
function publicState(room, viewerId) {
  return { code: room.code, status: room.status, settings: {budget:room.startingBudget, slots:room.slots, category:room.category}, players: room.players.map(p=>({id:p.id,name:p.name,avatar:p.avatar,role:p.role,connected:p.connected,balance:p.balance,team:p.team,teamPower:p.team.reduce((n,i)=>n+i.power,0),isYou:p.id===viewerId})), currentItem:room.currentItem, currentBid:room.currentBid, highestBidder:room.highestBidder, endsAt:room.endsAt, secondsLeft:room.status==='auction'?Math.max(0,Math.ceil((room.endsAt-Date.now())/1000)):0, itemIndex:room.itemIndex, totalItems:room.items.length, announcement:room.announcement, history:room.history.slice(-8), result:room.result, hostId:room.hostId };
}
function createRoom({name,avatar='wolf',budget,slots,category}, socketId) {
  if(typeof name!=='string'||!name.trim()||name.trim().length>24) throw Error('Enter a name (1–24 characters).');
  if(!Number.isSafeInteger(Number(budget))||Number(budget)<1||Number(budget)>1e12) throw Error('Budget must be a whole amount of at least ₹1 (max ₹1,00,00,00,00,000).');
  if(!Number.isInteger(Number(slots))||Number(slots)<1||Number(slots)>20) throw Error('Team slots must be between 1 and 20.');
  if(!Object.hasOwn(ITEMS,category)) throw Error('Choose a valid category.');
  if(!['wolf','crown','gavel'].includes(avatar)) avatar='wolf';
  const p={id:socketId,resumeToken:require('crypto').randomBytes(24).toString('hex'),name:name.trim(),avatar,role:1,connected:true,balance:Number(budget),team:[]};
  return {code:null,status:'lobby',startingBudget:Number(budget),slots:Number(slots),category,players:[p],hostId:socketId,items:ITEMS[category].map(x=>({...x})).sort(()=>Math.random()-.5),itemIndex:-1,currentItem:null,currentBid:0,highestBidder:null,endsAt:null,announcement:'Waiting for Player 2 to join.',history:[],result:null,settled:false,disconnectTimers:new Map()};
}
function addPlayer(room,{name,avatar='wolf'},socketId) {
  if(room.status!=='lobby'||room.players.length!==1) throw Error('This room is full or the auction has already started.');
  if(typeof name!=='string'||!name.trim()||name.trim().length>24) throw Error('Enter a name (1–24 characters).');
  if(!['wolf','crown','gavel'].includes(avatar)) avatar='wolf';
  room.players.push({id:socketId,resumeToken:require('crypto').randomBytes(24).toString('hex'),name:name.trim(),avatar,role:2,connected:true,balance:room.startingBudget,team:[]}); room.announcement=`${name.trim()} joined the arena.`; return room;
}
function beginNext(room) {
  if(room.players.some(p=>p.team.length<room.slots) && room.itemIndex+1<room.items.length) {
    room.itemIndex++; room.currentItem=room.items[room.itemIndex]; room.currentBid=0; room.highestBidder=null; room.endsAt=Date.now()+20000; room.settled=false; room.status='auction'; room.announcement='Bidding starts!'; return;
  }
  room.status='finished'; room.currentItem=null; const [a,b]=room.players; const ap=a.team.reduce((s,x)=>s+x.power,0), bp=b.team.reduce((s,x)=>s+x.power,0); room.result={winner:ap===bp?null:(ap>bp?a.id:b.id),draw:ap===bp,powers:{[a.id]:ap,[b.id]:bp},message:ap===bp?'DRAW':`${ap>bp?a.name:b.name} WINS!`}; room.announcement=room.result.message;
}
function settle(room) {
  if(room.status!=='auction'||room.settled) return false;
  room.settled=true;
  if(room.highestBidder) { const p=room.players.find(x=>x.id===room.highestBidder); if(p && p.balance>=room.currentBid && p.team.length<room.slots) {p.balance-=room.currentBid;p.team.push({...room.currentItem,paid:room.currentBid});room.announcement=`${room.currentItem.name} sold to ${p.name} for ₹${room.currentBid.toLocaleString('en-IN')}.`; room.history.push({text:room.announcement,type:'sold'});} else room.announcement=`No buyer. ${room.currentItem.name} was not sold.`; }
  else room.announcement=`No buyer. ${room.currentItem.name} was not sold.`;
  room.status='between'; room.endsAt=Date.now()+2400; return true;
}
function bid(room, playerId, increment) {
  if(room.status!=='auction'||Date.now()>=room.endsAt) throw Error('Bidding is closed for this item.');
  const p=room.players.find(x=>x.id===playerId); if(!p) throw Error('Player not found in this room.');
  if(!Number.isSafeInteger(increment)||increment<1||increment>1e12) throw Error('Bid increment must be a positive whole number.');
  if(p.team.length>=room.slots) throw Error('Your team is full.');
  const next=room.currentBid+increment; if(!Number.isSafeInteger(next)||next>p.balance) throw Error(`Not enough budget. Your balance is ₹${p.balance.toLocaleString('en-IN')}.`);
  room.currentBid=next; room.highestBidder=p.id; room.announcement=`${p.name} bid ₹${next.toLocaleString('en-IN')}.`; room.history.push({text:room.announcement,type:'bid',playerId:p.id}); return room.announcement;
}
module.exports={makeCode,publicState,createRoom,addPlayer,beginNext,settle,bid};
