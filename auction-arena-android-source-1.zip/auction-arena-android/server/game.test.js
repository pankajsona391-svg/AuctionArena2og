const test=require('node:test');const assert=require('node:assert/strict');const {createRoom,addPlayer,beginNext,bid,settle,makeCode}=require('./game');
function room(){const r=createRoom({name:'Alpha',budget:100,slots:2,category:'Marvel'},'p1');r.code='ABC234';addPlayer(r,{name:'Beta'},'p2');return r}
test('room code is six characters and unique',()=>{const c=makeCode(new Set(['ABC234']));assert.match(c,/^[A-Z2-9]{6}$/);assert.notEqual(c,'ABC234')});
test('both players get same custom budget and configured slots',()=>{const r=room();assert.equal(r.players[0].balance,100);assert.equal(r.players[1].balance,100);assert.equal(r.slots,2)});
test('bids are additive and a player can raise their own bid',()=>{const r=room();beginNext(r);bid(r,'p1',10);bid(r,'p2',5);bid(r,'p1',10);assert.equal(r.currentBid,25);assert.equal(r.highestBidder,'p1')});
test('server rejects unaffordable increments',()=>{const r=room();beginNext(r);bid(r,'p1',70);assert.throws(()=>bid(r,'p2',40),/Not enough budget/);assert.equal(r.currentBid,70)});
test('settlement charges only once and awards team item',()=>{const r=room();beginNext(r);bid(r,'p1',52);assert.equal(settle(r),true);assert.equal(r.players[0].balance,48);assert.equal(r.players[0].team.length,1);assert.equal(settle(r),false);assert.equal(r.players[0].balance,48)});
test('rejects invalid slot and budget settings',()=>{assert.throws(()=>createRoom({name:'A',budget:0,slots:1,category:'Marvel'},'x'));assert.throws(()=>createRoom({name:'A',budget:2,slots:21,category:'Marvel'},'x'))});
