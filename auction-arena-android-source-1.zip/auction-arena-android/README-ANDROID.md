# Auction Arena Android + Online Multiplayer

This is the Android Studio source project and Node.js multiplayer server for Auction Arena. It is **not a compiled APK** yet. A public server must be deployed before the app can play across different networks.

## Deploy the multiplayer server (one-time)
1. Upload this folder's contents to a GitHub repository.
2. In Render, create a new Web Service from that repository. The included `render.yaml` specifies `npm install`, `npm start`, and `/health`.
3. Wait for deployment and copy the HTTPS service URL, for example `https://auction-arena-multiplayer.onrender.com`.
4. Keep that service deployed. Both players need to use the same URL. Note: free hosting may sleep when idle, so the first connection can take a little while.

## Build the APK
1. Install Android Studio (with Android SDK 35) and JDK 17 or newer.
2. Open this folder as an Android Studio project.
3. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio creates the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.
5. Install the APK on both Android phones. On first launch, paste the deployed HTTPS server URL. The app saves it for later.

## Game flow
Player 1 creates a room and shares the six-character code. Player 2 enters the code and joins. Both phones can be on different Wi-Fi/mobile networks; both need internet access.

## Important
- This source package does not contain an APK binary because this build environment has Java but no Android SDK/Gradle installation, and the online server has not been deployed for you.
- Do not put private credentials into the app. The included game server is a starter deployment; for public production use add rate limiting, monitoring and persistent storage.

## Build the APK without installing Android Studio locally
The included GitHub Actions workflow `.github/workflows/build-apk.yml` builds a debug APK in the cloud. Push the project to GitHub, open **Actions > Build Auction Arena APK**, run the workflow (or wait for the first push build), and download the `auction-arena-debug-apk` artifact. You still need to deploy the multiplayer server separately and enter its URL in the app.
