package com.auctionarena.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.app.AlertDialog;
import android.view.inputmethod.InputType;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;
    private static final String KEY_URL = "server_url";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(11,16,32));
        getWindow().setNavigationBarColor(Color.rgb(11,16,32));
        prefs = getSharedPreferences("auction_arena", MODE_PRIVATE);
        String url = prefs.getString(KEY_URL, "");
        if (url.isEmpty()) showServerDialog(); else loadGame(url);
    }

    private void showServerDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 32, 48, 8);
        TextView note = new TextView(this);
        note.setText("Enter the public HTTPS server URL for Auction Arena. Both players must use the same server. Deploy this project's server first, then paste its URL here.");
        note.setTextSize(16);
        layout.addView(note);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://your-server.onrender.com");
        input.setText(prefs.getString(KEY_URL, ""));
        layout.addView(input);
        new AlertDialog.Builder(this)
            .setTitle("Connect to multiplayer")
            .setView(layout)
            .setCancelable(false)
            .setPositiveButton("Connect", (d, w) -> {
                String value = input.getText().toString().trim().replaceAll("/+$", "");
                if (!value.startsWith("https://")) {
                    Toast.makeText(this, "Use the public HTTPS URL", Toast.LENGTH_LONG).show();
                    showServerDialog(); return;
                }
                prefs.edit().putString(KEY_URL, value).apply();
                loadGame(value);
            })
            .setNeutralButton("How to set up", (d,w) -> new AlertDialog.Builder(this)
                .setTitle("Server setup")
                .setMessage("Upload the included project to a GitHub repository and create a Web Service on Render using the included render.yaml. After deployment, paste the service's HTTPS URL here. The server must stay online for multiplayer.")
                .setPositiveButton("OK", (dd,ww) -> showServerDialog()).show())
            .show();
    }

    private void loadGame(String url) {
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(11,16,32));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String target) {
                if (target.startsWith(url) || target.startsWith("https://")) { view.loadUrl(target); return true; }
                return true;
            }
            @Override public void onReceivedError(WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceError error) {
                if (request.isForMainFrame()) Toast.makeText(MainActivity.this, "Cannot reach server. Check internet or change server URL from menu/back.", Toast.LENGTH_LONG).show();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setTitle("Auction Arena")
            .setItems(new String[]{"Reload game", "Change server URL", "Exit"}, (d, which) -> {
                if (which == 0 && webView != null) webView.reload();
                else if (which == 1) showServerDialog(); else finish();
            }).show();
    }
}
